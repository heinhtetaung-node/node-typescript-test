
function App() {
  return (
    <div>
      <h1>Edit this app to complete LINE MAN Wongnai Frontend Assignment!</h1>
    </div>
  )
}

export default App
